from django.contrib import admin
from supporter.models import Ipaddress

admin.site.register(Ipaddress)
